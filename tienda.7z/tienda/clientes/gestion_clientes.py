clientes = []  # Initialize an empty list to store clients

def menu_clientes():
    while True:
        print("\n---Gestion De Clientes---")
        print("1. Agregar Cliente")
        print("2. Listar clientes")
        print("3. Buscar Cliente")
        print("4. Volver al menu principal")
        opcion = input("Elige una opcion: ")

        try:
            opcion = int(opcion)
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")
            continue

        if opcion == 1:
            agregar_cliente()
        elif opcion == 2:
            listar_clientes()
        elif opcion == 3:
            buscar_cliente()
        elif opcion == 4:
            print("Volver al menu principal...")
            break
        else:
            print("Error: Opción no válida. Por favor, intente de nuevo.")

def agregar_cliente():
    global clientes
    nombre_cliente = input("Ingrese el nombre del cliente: ")
    direccion_cliente = input("Ingrese la dirección del cliente: ")

    cliente = {
        "nombre": nombre_cliente,
        "direccion": direccion_cliente
    }

    clientes.append(cliente)
    print("Cliente agregado con éxito!")

def listar_clientes():
    global clientes
    if not clientes:
        print("No hay clientes agregados.")
    else:
        print("Clientes actuales:")
        for cliente in clientes:
            print(f"Nombre: {cliente['nombre']}, Dirección: {cliente['direccion']}")

def buscar_cliente():
    global clientes
    nombre_cliente = input("Ingrese el nombre del cliente a buscar: ")

    for cliente in clientes:
        if cliente["nombre"] == nombre_cliente:
            print(f"Cliente encontrado: Nombre: {cliente['nombre']}, Dirección: {cliente['direccion']}")
            return

    print("Cliente no encontrado.")

def obtener_clientes():
    return clientes