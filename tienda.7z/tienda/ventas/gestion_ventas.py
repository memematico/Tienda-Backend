clientes = []
productos = {}

def menu_ventas():
    global productos
    global clientes

    while True:
        print("\n---Gestion De Ventas---")
        print("1. Realizar Venta")
        print("2. Volver al menu principal")
        opcion = input("Elige una opcion: ")

        try:
            opcion = int(opcion)
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")
            continue

        if opcion == 1:
            realizar_venta()
        elif opcion == 2:
            print("Volver al menu principal...")
            break
        else:
            print("Error: Opción no válida. Por favor, intente de nuevo.")

def realizar_venta():
    global productos
    global clientes

    print("Productos disponibles:")
    for nombre, precio in productos.items():
        print(f"Nombre: {nombre}, Precio: {precio}")

    total_price = 0
    productos_vendidos = []

    while True:
        nombre_producto = input("Ingrese el nombre del producto a vender (o 'fin' para terminar): ").lower()

        if nombre_producto == 'fin':
            break

        if nombre_producto in [nombre.lower() for nombre in productos]:
            precio_producto = productos[[nombre for nombre in productos if nombre.lower() == nombre_producto][0]]
            total_price += precio_producto
            productos_vendidos.append((nombre_producto, precio_producto))
        else:
            print("Error: Producto no encontrado.")
            continue

    if not productos_vendidos:
        print("No se han agregado productos a la venta.")
        return

    print("Clientes disponibles:")
    for i, cliente in enumerate(clientes):
        print(f"{i+1}. Nombre: {cliente['nombre']}, Dirección: {cliente['direccion']}")

    try:
        selected_client_index = int(input("Ingrese el número del cliente: ")) - 1
    except ValueError:
        print("Error: Por favor, ingrese un número válido.")
        return

    if 0 <= selected_client_index < len(clientes):
        cliente = clientes[selected_client_index]
    else:
        print("Error: Cliente no encontrado.")
        return

    print(f"Venta realizada con éxito! Productos: {', '.join([f'{nombre} ({precio})' for nombre, precio in productos_vendidos])}, Total: {total_price}, Cliente: {cliente['nombre']}")

# Importing products and clients from separate modules
from productos.gestion_productos import obtener_productos
from clientes.gestion_clientes import obtener_clientes

productos = obtener_productos()
clientes = obtener_clientes()

menu_ventas()