productos = {}

def menu_productos():
    while True:
        print("\n---Gestion De Producto---")
        print("1. Agregar Producto")
        print("2. Listar productos")
        print("3. Buscar Producto")
        print("4. Volver al menu principal")
        opcion = input("Elige una opcion: ")

        try:
            opcion = int(opcion)
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")
            continue

        if opcion == 1:
            agregar_producto()
        elif opcion == 2:
            listar_productos()
        elif opcion == 3:
            buscar_producto()
        elif opcion == 4:
            print("Volver al menu principal...")
            break
        else:
            print("Error: Opción no válida. Por favor, intente de nuevo.")

def agregar_producto():
    global productos
    nombre_producto = input("Ingrese el nombre del producto: ")
    precio_producto = float(input("Ingrese el precio del producto: "))

    productos[nombre_producto] = precio_producto
    print("Producto agregado con éxito!")

def listar_productos():
    global productos
    if not productos:
        print("No hay productos agregados.")
    else:
        print("Productos actuales:")
        for nombre, precio in productos.items():
            print(f"Nombre: {nombre}, Precio: {precio}")

def buscar_producto():
    global productos
    nombre_producto = input("Ingrese el nombre del producto a buscar: ")

    if nombre_producto in productos:
        print(f"Producto encontrado: Nombre: {nombre_producto}, Precio: {productos[nombre_producto]}")
    else:
        print("Producto no encontrado.")

def obtener_productos():
    return productos