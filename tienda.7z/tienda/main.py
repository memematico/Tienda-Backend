from productos.gestion_productos import menu_productos
from clientes.gestion_clientes import menu_clientes
from ventas.gestion_ventas import menu_ventas

def menu_principal():
    while True:
        print("\nMenu Principal")
        print("1 - Gestion productos")
        print("2 - Gestion Clientes")
        print("3 - Gestion Ventas")
        print("4 - salir")
        opcion = input("Ingrese una opcion: ")

        try:
            opcion = int(opcion)
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")
            continue

        if opcion == 1:
            menu_productos()  # Corrected
        elif opcion == 2:
            menu_clientes()
        elif opcion == 3:
            menu_ventas()  # Corrected
        elif opcion == 4:
            print("Saliendo del sistema...")
            break
        else:
            print("Error: Opción no válida. Por favor, intente de nuevo.")

if __name__ == "__main__":
    from main import menu_principal
    menu_principal()